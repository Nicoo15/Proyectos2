using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ejemplo1 : MonoBehaviour
{

    [SerializeField] Color elcolorNuevo;

    Color antiguo;

    //Inicializaci�n
    private void Awake()
    {
      //  print("awake");
    }

    private void Start()
    {
        
     //   Debug.Log("start");
    }

    //L�gica
    private void Update()
    {
      //  print("Update cada frame" + Time.deltaTime);

    }

    private void LateUpdate()
    {
      //  print("update pero despues");
    }

    //f�sica
    private void FixedUpdate()
    {
       // print("FixedUpdate " + Time.fixedDeltaTime);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        print("Colisono con " + collision.gameObject.name);
        antiguo = collision.gameObject.GetComponent<SpriteRenderer>().color;
        collision.gameObject.GetComponent<SpriteRenderer>().color = elcolorNuevo;

    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        collision.gameObject.GetComponent<SpriteRenderer>().color = antiguo;
        this.gameObject.SetActive(false);
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        
    }

    private void OnTriggerExit(Collider other)
    {
        
    }

    private void OnDisable()
    {
        print("desactivado el objeto " + this.gameObject.name);
    }

    private void OnEnable()
    {
        
    }

    private void OnApplicationQuit()
    {
        
    }



}
