using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TransalcionesYRotaciones : MonoBehaviour
{
    public float speed =5f;
    public Vector2 flyForce ;
    private void Update()
    {
        /* if (Input.GetKeyDown(KeyCode.D)) {
             print("pulsa down");
         }
         if (Input.GetKeyUp(KeyCode.D))
         {
             print("pulsa Up");
         }*/
        /*  if (Input.GetKey(KeyCode.A))
          {
              transform.Translate(Vector2.left * speed * Time.deltaTime);
          }*/

        // print(Input.GetAxis("Horizontal"));
        // transform.Translate(Vector2.right * speed * Time.deltaTime * Input.GetAxis("Horizontal"));

        if (Input.GetKey(KeyCode.Space)) {
            GetComponent<Rigidbody2D>().AddForce( flyForce * Time.deltaTime);
            print("velocidad " + GetComponent<Rigidbody2D>().velocity.magnitude);
        }

    }
}
